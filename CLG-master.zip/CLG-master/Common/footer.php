<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
          <h2>INTER PROGRAMS</h2>
            <ul>
              <li><a href="">FSC Pre Medical</a></li>
              <li><a href="">FSC Pre Engineering</a></li>
              <li><a href="">ICS</a></li>
            <ul>

               <h2>UNDERGRADUATE PROGRAMS</h2>
            <ul>
              <li><a href="">BS Information Technology</a></li>
              <li><a href="">BS Chemistry</a></li>
              <li><a href="">BS Economics</a></li>
              <li><a href="">BS English</a></li>
           
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>CONTACT DETAILS</h2>
              <p>Address: Tahlianwala near Bilal Town Jhelum</p>
              <p>Telephones: 0544-734752</p>
              <p>E-mail: gc.pgcjhelum.hed@gmail.com</p>
        </div>
      </div>
    </div>
    </div>
  <p class="footer-bottom-text">CopyRights © SamKulArj 2022</p>
</footer>