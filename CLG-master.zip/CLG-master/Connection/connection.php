<?php 
	$con=mysqli_connect("localhost","root","","college");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>