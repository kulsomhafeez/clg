<!DOCTYPE html>
<html>
<head>
	<title>Academics</title>
</head>
<body>
	<?php include('common/header.php') ?>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Engineering and Technology</h4>
			</div>
			<div class="container">
				<div class="row">
		
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Art, Social Sciences and Humanities</h4>
			</div>
			<div class="container">
				<div class="row">
					
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Computer Sciences</h4>
			</div>
			<div class="container">
				<div class="row">
					
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Business Administration</h4>
			</div>
			<div class="container">
				<div class="row">
						
				</div>
			</div>
		</div>
	</div>
</body>
</html>